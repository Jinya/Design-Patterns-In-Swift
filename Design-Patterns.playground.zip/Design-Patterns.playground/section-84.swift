let humanInterface = HEVSuitHumanInterface()
humanInterface.administerMorphine()