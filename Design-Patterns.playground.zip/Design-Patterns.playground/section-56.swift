let instance = SingletonClass.shared
